import requests, os
from dotenv import load_dotenv
load_dotenv()

r = requests.post(
    'https://api.prospeo.io/search-person',
    headers={'X-KEY': os.getenv('PROSPEO_API_KEY'), 'Content-Type': 'application/json'},
    json={'page': 1, 'filters': {'company': {'websites': {'include': ['freshworks.com']}}}}
)
result = r.json()['results'][0]
print('person keys:', list(result['person'].keys()))
print('person_id value:', result['person'].get('person_id'))
print('id value:', result['person'].get('id'))