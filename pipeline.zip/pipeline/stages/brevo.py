import requests
import os
import time

YOUR_NAME = "Surya"
YOUR_EMAIL = "suryasunadh89@gmail.com" 

def build_email_body(first_name, company_domain):
    """Write your personalized outreach email here."""
    return f"""
    <html><body>
    <p>Hi {first_name},</p>

    <p>I came across <strong>{company_domain}</strong> and was impressed 
    by what your team is building.</p>

    <p>I'm Surya — a software engineer who's been working on automation 
    tools that help sales and growth teams move faster with less manual work.</p>

    <p>Would you be open to a quick 10-minute call this week to see 
    if there's a fit?</p>

    <p>Best,<br>
    Surya<br>
    linkedin.com/in/your-profile</p>
    </body></html>
    """

def send_emails(contacts):
    print(f"\n📨 Sending emails to {len(contacts)} contacts...")
    
    sent = 0
    failed = 0

    for person in contacts:
        first_name = person.get("first_name", "there")
        last_name = person.get("last_name", "")
        email = person.get("email")
        company_domain = person.get("company_domain", "your company")

        if not email:
            print(f"⚠️  Skipping {first_name} — no email")
            continue

        try:
            response = requests.post(
                "https://api.brevo.com/v3/smtp/email",
                headers={
                    "api-key": os.getenv("BREVO_API_KEY"),
                    "Content-Type": "application/json",
                    "accept": "application/json"
                },
                json={
                    "sender": {
                        "name": YOUR_NAME,
                        "email": YOUR_EMAIL
                    },
                    "to": [{
                        "email": email,
                        "name": f"{first_name} {last_name}".strip()
                    }],
                    "subject": f"Quick question, {first_name}",
                    "htmlContent": build_email_body(first_name, company_domain)
                }
            )

            data = response.json()

            if response.status_code == 201:
                print(f"✅ Sent to {email} (messageId: {data.get('messageId')})")
                sent += 1
            else:
                print(f"❌ Failed for {email}: {data}")
                failed += 1

        except Exception as e:
            print(f"❌ Error sending to {email}: {e}")
            failed += 1

        time.sleep(1)  

    print(f"\n🎉 Done! Sent: {sent} | Failed: {failed}")