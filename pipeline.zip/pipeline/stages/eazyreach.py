import requests
import os
import time

def resolve_emails(contacts):
    print(f"📧 [Stage 3] Resolving emails for {len(contacts)} contacts...")

    if not contacts:
        return []

    enriched = []

    for person in contacts:
        first_name = person.get("first_name", "")
        last_name = person.get("last_name", "")
        full_name = f"{first_name} {last_name}".strip()
        company_domain = person.get("company_domain", "")

        try:
            response = requests.post(
                "https://api.prospeo.io/enrich-person",
                headers={
                    "X-KEY": os.getenv("PROSPEO_API_KEY"),
                    "Content-Type": "application/json"
                },
                json={
                    "only_verified_email": True,
                    "data": {
                        "full_name": full_name,
                        "company_website": company_domain
                    }
                },
                timeout=15
            )

            data = response.json()

            if data.get("error"):
                print(f"  ⚠️  No email for {full_name}: {data.get('error_code')}")
                continue

            email = data.get("person", {}).get("email", {}).get("email")

            if email:
                person["email"] = email
                enriched.append(person)
                print(f"  ✅ {full_name} → {email}")
            else:
                print(f"  ⚠️  No email found for {full_name}")

        except Exception as e:
            print(f"  ❌ Error for {full_name}: {e}")

        time.sleep(1)

    print(f"\n  📦 Stage 3 complete — {len(enriched)} emails resolved out of {len(contacts)}")
    return enriched