import requests
import os

def find_lookalikes(seed_domain):
    print(f"🔍 Searching lookalikes for: {seed_domain}")

    response = requests.post(
        "https://api.ocean.io/v3/search/companies",
        headers={
            "X-Api-Token": os.getenv("OCEAN_API_KEY"),
            "Content-Type": "application/json"
        },
        json={
            "size": 10,
            "companiesFilters": {
                "lookalikeDomains": [seed_domain]
            }
        }
    )

    data = response.json()

    if "detail" in data and data["detail"] != "OK":
        print(f"  ❌ Ocean.io error: {data['detail']}")
        return []

    companies = data.get("companies", [])

    if not companies:
        print("⚠️ No lookalike companies found.")
        return []

    # Extract domains only
    domains = []
    for item in companies:
        domain = item.get("company", {}).get("domain")
        if domain:
            domains.append(domain)

    print(f"✅ Found {len(domains)} lookalike companies")
    return domains