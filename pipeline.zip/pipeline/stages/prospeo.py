import requests
import os

def find_decision_makers(domains):
    print(f"👤 Searching decision-makers for {len(domains)} companies...")

    all_contacts = []

    response = requests.post(
        "https://api.prospeo.io/search-person",
        headers={
            "X-KEY": os.getenv("PROSPEO_API_KEY"),
            "Content-Type": "application/json"
        },
        json={
            "page": 1,
            "filters": {
                "company": {
                    "websites": {
                        "include": domains
                    }
                },
                "person_seniority": {
                    "include": ["Founder/Owner", "C-Suite", "Vice President", "Director"]
                }
            }
        }
    )

    data = response.json()

    if data.get("error"):
        print(f"❌ Prospeo search error: {data.get('error_code')}")
        return []

    results = data.get("results", [])
    print(f"✅ Found {len(results)} decision-makers")

    for result in results:
        person = result.get("person", {})
        person_id = person.get("person_id")
        first_name = person.get("first_name", "")
        last_name = person.get("last_name", "")
        job_title = person.get("current_job_title", "")
        linkedin_url = person.get("linkedin_url")
        company_domain = result.get("company", {}).get("domain", "")
        email = person.get("email")

        if not person_id:
            continue

        if linkedin_url:
            all_contacts.append({
                "first_name": first_name,
                "last_name": last_name,
                "job_title": job_title,
                "company_domain": company_domain,
                "linkedin_url": linkedin_url,
                "person_id": person_id,
                "email": email
            })
            print(f"  ✅ {first_name} {last_name} ({job_title}) @ {company_domain}")
        else:
            print(f"  ⚠️  No LinkedIn URL for {first_name} {last_name}")
            
    response2 = requests.post(
    "https://api.prospeo.io/linkedin-email-finder",
    headers={"X-KEY": os.getenv("PROSPEO_API_KEY"), "Content-Type": "application/json"},
    json={"url": linkedin_url}
)
    data2 = response2.json()
    email = data2.get("email", {}).get("email")  

    print(f"\n  📦 Stage 2 complete — {len(all_contacts)} contacts found")
    return all_contacts