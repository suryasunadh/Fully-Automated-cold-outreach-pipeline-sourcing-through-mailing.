from dotenv import load_dotenv
from stages.ocean import find_lookalikes
from stages.prospeo import find_decision_makers
from stages.eazyreach import resolve_emails
from stages.brevo import send_emails

load_dotenv()


def print_banner():
    print("""
      🚀 Automated Outreach Pipeline             
      Ocean → Prospeo → Eazyreach → Brevo       
    """)


def print_summary(domains, contacts, enriched):
    print("""
  📊 PIPELINE SUMMARY
      """)
    print(f"  Stage 1 — Lookalike companies found : {len(domains)}")
    print(f"  Stage 2 — Decision-makers found     : {len(contacts)}")
    print(f"  Stage 3 — Emails resolved           : {len(enriched)}")


def safety_checkpoint(enriched):
    """Show who will be emailed before firing — required by assignment."""
    print("""
⚠️  SAFETY CHECKPOINT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  The following people are about to receive emails:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━""")

    for i, person in enumerate(enriched, 1):
        name = f"{person.get('first_name', '')} {person.get('last_name', '')}".strip()
        email = person.get("email", "N/A")
        title = person.get("job_title", "N/A")
        company = person.get("company_domain", "N/A")
        print(f"  {i}. {name} | {title} @ {company} | {email}")

    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    confirm = input(f"\n  Type YES to send {len(enriched)} emails: ").strip()
    return confirm == "YES"


def main():
    print_banner()

    seed = input("  Enter seed domain (e.g. stripe.com): ").strip().lower()
    if not seed:
        print("  ❌ No domain entered. Exiting.")
        return

   
    domains = find_lookalikes(seed)

    if not domains:
        print("\n  ❌ No lookalike companies found. Pipeline stopped.")
        return

    
    contacts = find_decision_makers(domains)

    if not contacts:
        print("\n  ❌ No decision-makers found. Pipeline stopped.")
        return

    
    enriched = resolve_emails(contacts)

    if not enriched:
        print("\n  ❌ No emails resolved. Pipeline stopped.")
        return

    
    print_summary(domains, contacts, enriched)

    if not safety_checkpoint(enriched):
        print("\n  🛑 Cancelled. No emails sent.")
        return

    
    send_emails(enriched)

    print("\n  🎉 Pipeline complete! Check your Brevo dashboard for delivery stats.")


if __name__ == "__main__":
    main()